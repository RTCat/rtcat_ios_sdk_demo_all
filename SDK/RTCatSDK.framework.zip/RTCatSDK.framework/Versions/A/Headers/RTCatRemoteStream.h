//
//  RemoteStream.h
//  RTCatSDK
//
//  Created by cong chen on 9/9/16.
//  Copyright © 2016 cong chen. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RTCatAbstractStream.h"

/**
 *  远程流
 */
@interface RTCatRemoteStream : RTCatAbstractStream

@end
